const state={role:null,name:"Nara",page:"Início"};

const data={
  aluno:{label:"Aluno",avatar:"A",menu:[["⌂","Início"],["▣","Disciplinas"],["✓","Atividades"],["★","Notas"],["◷","Frequência"],["◉","Avisos"]]},
  professor:{label:"Professor",avatar:"P",menu:[["⌂","Início"],["▤","Minhas turmas"],["✓","Frequência"],["★","Notas"],["□","Atividades"],["◉","Comunicados"]]},
  direcao:{label:"Direção",avatar:"D",menu:[["⌂","Visão geral"],["♟","Alunos"],["♟","Professores"],["▦","Turmas"],["▥","Relatórios"],["◉","Comunicados"]]}
};

const $=id=>document.getElementById(id);

$("loginForm").addEventListener("submit",e=>{
  e.preventDefault();
  const raw=$("user").value.trim();
  state.name=(raw.split("@")[0]||"Usuário").replace(/[._-]/g," ");
  state.name=state.name.split(" ").map(x=>x?x[0].toUpperCase()+x.slice(1):"").join(" ");
  login($("role").value);
});

function login(role){
  state.role=role;
  state.page=data[role].menu[0][1];
  $("login").classList.add("hidden");
  $("dashboard").classList.remove("hidden");
  $("sideName").textContent=state.name;
  $("topName").textContent=state.name;
  $("sideRole").textContent=data[role].label;
  $("avatar").textContent=data[role].avatar;
  $("topAvatar").textContent=data[role].avatar;
  renderNav();render();
}

$("logout").onclick=()=>{
  $("dashboard").classList.add("hidden");
  $("login").classList.remove("hidden");
  $("password").value="";
};

$("menuBtn").onclick=()=>$("sidebar").classList.toggle("open");
document.querySelector(".sidebar").id="sidebar";

function renderNav(){
  $("nav").innerHTML=data[state.role].menu.map(([icon,label])=>
    `<button class="nav-item ${label===state.page?"active":""}" onclick="go('${label}')">${icon}<span>${label}</span></button>`
  ).join("");
}

function go(page){
  state.page=page;
  renderNav();render();
  $("sidebar").classList.remove("open");
}

function render(){
  const r=state.role;
  $("roleEyebrow").textContent=data[r].label.toUpperCase();
  $("pageTitle").textContent=state.page;
  $("dashboardContent").innerHTML=state.page===data[r].menu[0][1]?home(r):generic(r,state.page);
}

function home(r){
  if(r==="aluno") return `
    <div class="welcome"><h2>Olá, ${state.name}! 👋</h2><p>Veja seus principais dados escolares de hoje.</p></div>
    <div class="cards">
      ${stat("NOTA MÉDIA","8,7","↑ Bom desempenho")}
      ${stat("FREQUÊNCIA","94%","↑ 2% este mês")}
      ${stat("ATIVIDADES","12","4 pendentes")}
      ${stat("AVISOS","3","Novos")}
    </div>
    <div class="grid2">
      <div class="panel"><h3>Próximas atividades</h3><div class="list">
        ${row("Matemática","Lista de exercícios • amanhã","Pendente")}
        ${row("Português","Produção de texto • sexta","Em andamento")}
        ${row("Ciências","Trabalho em grupo • 08/10","Agendado")}
      </div></div>
      <div class="panel"><h3>Frequência</h3><strong style="font-size:36px">94%</strong><div class="progress"><span style="width:94%"></span></div><p class="muted">Excelente presença nas aulas.</p></div>
    </div>`;

  if(r==="professor") return `
    <div class="welcome"><h2>Olá, ${state.name}! 👋</h2><p>Tenha uma visão rápida das suas turmas e atividades.</p></div>
    <div class="cards">
      ${stat("TURMAS","4","")}
      ${stat("ALUNOS","126","")}
      ${stat("ATIVIDADES","18","6 pendentes")}
      ${stat("FREQUÊNCIA MÉDIA","92%","")}
    </div>
    <div class="grid2">
      <div class="panel"><h3>Minhas turmas</h3><div class="list">
        ${row("9º Ano A","32 alunos","92% frequência")}
        ${row("8º Ano B","29 alunos","95% frequência")}
        ${row("7º Ano A","34 alunos","90% frequência")}
      </div></div>
      <div class="panel"><h3>Ações rápidas</h3><div class="list">
        ${row("＋","Lançar frequência","Hoje")}
        ${row("★","Lançar notas","7 pendentes")}
        ${row("□","Criar atividade","Novo")}
      </div></div>
    </div>`;

  return `
    <div class="welcome"><h2>Visão geral da escola</h2><p>Acompanhe os principais indicadores do GESTKA.</p></div>
    <div class="cards">
      ${stat("ALUNOS","1.246","↑ 3,2%")}
      ${stat("PROFESSORES","78","")}
      ${stat("TURMAS","45","")}
      ${stat("FREQUÊNCIA","92%","")}
    </div>
    <div class="grid2">
      <div class="panel"><h3>Indicadores</h3>${bar("Frequência geral",92)}${bar("Atividades entregues",86)}${bar("Notas lançadas",97)}</div>
      <div class="panel"><h3>Atalhos</h3><div class="list">
        ${row("♟","Gerenciar alunos","1.246")}
        ${row("♟","Gerenciar professores","78")}
        ${row("▥","Relatórios","12 disponíveis")}
      </div></div>
    </div>`;
}

function stat(label,value,trend){
  return `<div class="stat"><small>${label}</small><strong>${value}</strong>${trend?`<div class="trend">${trend}</div>`:""}</div>`;
}

function row(a,b,c){
  return `<div class="row"><div class="left"><div class="dot"></div><div><strong>${b}</strong><div class="muted">${a}</div></div></div><span class="badge">${c}</span></div>`;
}

function bar(a,v){
  return `<div style="margin:16px 0"><div style="display:flex;justify-content:space-between;font-size:12px"><span>${a}</span><b>${v}%</b></div><div class="progress"><span style="width:${v}%"></span></div></div>`;
}

function generic(r,p){
  const content={
    "Disciplinas":[["Matemática","Professor Carlos","8,9"],["Português","Professora Ana","9,1"],["Ciências","Professor João","8,5"]],
    "Atividades":[["Lista de Matemática","Entrega amanhã","Pendente"],["Produção de texto","Entrega sexta","Em andamento"],["Trabalho de Ciências","08/10","Agendado"]],
    "Notas":[["Matemática","1º trimestre","8,9"],["Português","1º trimestre","9,1"],["Ciências","1º trimestre","8,5"]],
    "Frequência":[["Agosto","Presença","95%"],["Setembro","Presença","94%"],["Total","Frequência geral","94%"]],
    "Avisos":[["Reunião escolar","Comunicado da direção","Novo"],["Feira de Ciências","Evento escolar","08/10"],["Calendário","Atualização","Publicado"]]
  };
  const items=content[p]||[
    ["GESTKA","Área em desenvolvimento","MVP"],
    ["Interface","Pronta para receber dados reais","Próximo passo"],
    ["Dados","Estrutura preparada","Demonstração"]
  ];
  return `<div class="panel"><h3>${p}</h3><p class="muted">Área do perfil ${data[r].label.toLowerCase()}.</p><div class="list">
    ${items.map(x=>row(x[0],x[1],x[2])).join("")}
  </div></div>`;
}

function showToast(message){
  const t=$("toast");t.textContent=message;t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"),2200);
}
